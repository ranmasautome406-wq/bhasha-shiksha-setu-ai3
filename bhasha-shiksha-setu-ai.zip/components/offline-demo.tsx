'use client'

import { BookMarked, Wifi, WifiOff } from 'lucide-react'
import { SectionHeading, DemoBadge } from './section'
import { useStore } from './store'
import { cn } from '@/lib/utils'

export function OfflineDemo() {
  const { offline, setOffline, saved } = useStore()

  const stats = [
    { label: 'Saved Lessons', value: 12 + saved.length },
    { label: 'Worksheets', value: 8 },
    { label: 'Flashcards', value: 24 },
  ]

  return (
    <section id="offline" className="scroll-mt-20 py-16 sm:py-20">
      <div className="mx-auto max-w-5xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Low-Connectivity Ready"
          title="Learning Even With Limited Connectivity"
          subtitle="Many classrooms may have limited or unreliable internet. Bhasha Shiksha Setu keeps important learning resources available offline."
        />

        <div className="mt-10 grid gap-6 lg:grid-cols-2">
          <div
            className={cn(
              'flex flex-col gap-5 rounded-3xl border p-6 transition-colors',
              offline ? 'border-accent/50 bg-accent/5' : 'border-border bg-card',
            )}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span
                  className={cn(
                    'flex h-11 w-11 items-center justify-center rounded-xl',
                    offline ? 'bg-accent text-accent-foreground' : 'bg-secondary text-muted-foreground',
                  )}
                >
                  {offline ? <WifiOff className="h-5 w-5" /> : <Wifi className="h-5 w-5" />}
                </span>
                <div>
                  <p className="font-display font-bold">Offline Mode</p>
                  <p className="text-sm text-muted-foreground">
                    {offline ? 'Resources served from local cache' : 'Currently online'}
                  </p>
                </div>
              </div>
              <button
                role="switch"
                aria-checked={offline}
                aria-label="Toggle offline mode"
                onClick={() => setOffline(!offline)}
                className={cn(
                  'relative h-7 w-12 rounded-full transition-colors',
                  offline ? 'bg-accent' : 'bg-input',
                )}
              >
                <span
                  className={cn(
                    'absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-all',
                    offline ? 'left-6' : 'left-1',
                  )}
                />
              </button>
            </div>

            {offline ? (
              <span className="flex w-fit items-center gap-2 rounded-full bg-accent/15 px-3 py-1.5 text-sm font-semibold text-accent-foreground">
                <span className="h-2 w-2 rounded-full bg-accent" /> Offline Ready
              </span>
            ) : null}

            <div className="grid grid-cols-3 gap-3">
              {stats.map((s) => (
                <div key={s.label} className="rounded-2xl border border-border bg-card p-3 text-center">
                  <p className="font-display text-2xl font-extrabold text-primary">{s.value}</p>
                  <p className="text-xs text-muted-foreground">{s.label}</p>
                </div>
              ))}
            </div>
            <DemoBadge>Prototype Offline Demonstration</DemoBadge>
          </div>

          <div className="flex flex-col gap-3 rounded-3xl border border-border bg-card p-6">
            <h3 className="font-display font-bold">Saved Lessons</h3>
            {saved.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                Save a lesson from the Language Bridge to open it here — even while offline.
              </p>
            ) : (
              <ul className="flex flex-col gap-2">
                {saved.map((l) => (
                  <li
                    key={l.id}
                    className="flex items-center gap-3 rounded-xl border border-border bg-secondary/30 px-3 py-2.5"
                  >
                    <BookMarked className="h-4 w-4 shrink-0 text-primary" aria-hidden />
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold">
                        {l.topic} · {l.language}
                      </p>
                      <p className="truncate text-xs text-muted-foreground">{l.translated}</p>
                    </div>
                    <span className="ml-auto text-xs font-medium text-accent-foreground">Available offline</span>
                  </li>
                ))}
              </ul>
            )}
            <p className="mt-auto text-xs text-muted-foreground">
              Cached with your browser&apos;s localStorage. A production version would support on-device
              AI/NLP models and locally cached resources.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
