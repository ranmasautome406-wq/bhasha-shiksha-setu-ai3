'use client'

import { CheckCircle2, Info, XCircle } from 'lucide-react'
import { useStore } from './store'
import { cn } from '@/lib/utils'

export function ToastViewport() {
  const { toasts } = useStore()
  return (
    <div
      className="pointer-events-none fixed inset-x-0 bottom-4 z-[60] flex flex-col items-center gap-2 px-4"
      role="region"
      aria-live="polite"
      aria-label="Notifications"
    >
      {toasts.map((t) => (
        <div
          key={t.id}
          className={cn(
            'animate-fade-up pointer-events-auto flex w-full max-w-md items-start gap-3 rounded-xl border px-4 py-3 text-sm font-medium shadow-lg glass',
            t.tone === 'success' && 'border-accent/40 text-accent-foreground',
            t.tone === 'error' && 'border-destructive/40 text-destructive',
            t.tone === 'info' && 'border-primary/30 text-foreground',
          )}
        >
          {t.tone === 'success' ? (
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
          ) : t.tone === 'error' ? (
            <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
          ) : (
            <Info className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
          )}
          <span className="text-pretty">{t.message}</span>
        </div>
      ))}
    </div>
  )
}
