'use client'

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react'
import * as api from '@/lib/api'
import {
  DEMO_ORIGINAL_LESSON,
  type LanguageCode,
} from '@/lib/demo-data'

/* ---------------------------------- types --------------------------------- */

export type Toast = { id: number; message: string; tone: 'info' | 'success' | 'error' }

export type UploadedImage = { url: string; name: string; size: number; dimensions?: string }

export type Ocr = { subject: string; grade: string; topic: string; extractedText: string }

export type SavedLesson = {
  id: string
  topic: string
  language: string
  translated: string
  savedAt: number
}

type WorksheetQ = {
  id: number
  type: string
  hindi: string
  target: string
  options: string[]
  answer: string
}

type Flashcard = { emoji: string; hindi: string; target: string; pronunciation: string }

type StoreValue = {
  /* toasts */
  toasts: Toast[]
  toast: (message: string, tone?: Toast['tone']) => void

  /* scanner */
  image: UploadedImage | null
  setImage: (img: UploadedImage | null) => void
  useDemoImage: () => void
  scanning: boolean
  scanProgress: number
  scanStep: number
  ocr: Ocr | null
  setOcrText: (text: string) => void
  analyze: () => Promise<void>

  /* language + translation */
  target: LanguageCode
  setTarget: (t: LanguageCode) => void
  translation: string | null
  runTranslate: (text?: string) => Promise<void>

  /* simplifier */
  originalLesson: string
  grade: 1 | 2 | 3
  simplified: string | null
  runSimplify: (g?: 1 | 2 | 3) => Promise<void>

  /* voice */
  voiceResult: { spoken: string; translated: string; responseTime: number } | null
  runVoice: () => Promise<void>

  /* worksheet */
  worksheet: WorksheetQ[] | null
  runWorksheet: (opts: { count: number; target: LanguageCode; types: string[] }) => Promise<void>

  /* flashcards */
  flashcards: Flashcard[] | null
  runFlashcards: () => Promise<void>

  /* offline + saved */
  offline: boolean
  setOffline: (v: boolean) => void
  saved: SavedLesson[]
  saveLesson: (l: Omit<SavedLesson, 'id' | 'savedAt'>) => void
  removeSaved: (id: string) => void

  /* demo */
  demoRunning: boolean
  demoStep: number
  demoTotal: number
  startFullDemo: () => void
  skipDemo: () => void
}

const StoreContext = createContext<StoreValue | null>(null)

export function useStore() {
  const ctx = useContext(StoreContext)
  if (!ctx) throw new Error('useStore must be used within StoreProvider')
  return ctx
}

const wait = (ms: number) => new Promise((r) => setTimeout(r, ms))
const scrollTo = (id: string) => {
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
}

/* -------------------------------- provider -------------------------------- */

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([])
  const toastId = useRef(0)
  const toast = useCallback((message: string, tone: Toast['tone'] = 'info') => {
    const id = ++toastId.current
    setToasts((t) => [...t, { id, message, tone }])
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200)
  }, [])

  const [image, setImageState] = useState<UploadedImage | null>(null)
  const [scanning, setScanning] = useState(false)
  const [scanProgress, setScanProgress] = useState(0)
  const [scanStep, setScanStep] = useState(0)
  const [ocr, setOcr] = useState<Ocr | null>(null)

  const [target, setTarget] = useState<LanguageCode>('santhali')
  const [translation, setTranslation] = useState<string | null>(null)

  const [grade, setGrade] = useState<1 | 2 | 3>(1)
  const [simplified, setSimplified] = useState<string | null>(null)

  const [voiceResult, setVoiceResult] = useState<StoreValue['voiceResult']>(null)
  const [worksheet, setWorksheet] = useState<WorksheetQ[] | null>(null)
  const [flashcards, setFlashcards] = useState<Flashcard[] | null>(null)

  const [offline, setOffline] = useState(false)
  const [saved, setSaved] = useState<SavedLesson[]>([])

  const [demoRunning, setDemoRunning] = useState(false)
  const [demoStep, setDemoStep] = useState(0)
  const demoTotal = 8
  const demoAbort = useRef(false)

  /* load saved lessons + offline flag from localStorage */
  useEffect(() => {
    try {
      const raw = localStorage.getItem('bss_saved')
      if (raw) setSaved(JSON.parse(raw))
      setOffline(localStorage.getItem('bss_offline') === '1')
    } catch {
      /* ignore */
    }
  }, [])

  const persistSaved = useCallback((list: SavedLesson[]) => {
    setSaved(list)
    try {
      localStorage.setItem('bss_saved', JSON.stringify(list))
    } catch {
      /* ignore */
    }
  }, [])

  const setOfflinePersist = useCallback(
    (v: boolean) => {
      setOffline(v)
      try {
        localStorage.setItem('bss_offline', v ? '1' : '0')
      } catch {
        /* ignore */
      }
    },
    [],
  )

  const setImage = useCallback((img: UploadedImage | null) => {
    setImageState(img)
    if (!img) {
      setOcr(null)
      setScanProgress(0)
      setScanStep(0)
    }
  }, [])

  const useDemoImage = useCallback(() => {
    setImageState({ url: '/demo-textbook.png', name: 'demo-textbook.png', size: 184320, dimensions: '1024 × 768' })
    toast('Demo textbook image loaded', 'success')
  }, [toast])

  const analyze = useCallback(async () => {
    if (!image) return
    setScanning(true)
    setScanStep(0)
    setScanProgress(0)
    for (let s = 1; s <= 5; s++) {
      setScanStep(s)
      for (let p = 0; p <= 20; p++) {
        await wait(14)
        setScanProgress((s - 1) * 20 + p)
      }
    }
    setScanProgress(100)
    const result = await api.analyzeImage({ name: image.name, size: image.size })
    setOcr(result)
    setScanning(false)
    toast('AI analysis complete', 'success')
  }, [image, toast])

  const setOcrText = useCallback((text: string) => {
    setOcr((o) => (o ? { ...o, extractedText: text } : o))
  }, [])

  const runTranslate = useCallback(
    async (text?: string) => {
      const src = text ?? ocr?.extractedText ?? 'गिनती कीजिए और सही संख्या लिखिए।'
      const res = await api.translate(src, target)
      setTranslation(res.translated)
      return
    },
    [ocr, target],
  )

  const runSimplify = useCallback(async (g?: 1 | 2 | 3) => {
    const chosen = g ?? grade
    setGrade(chosen)
    const res = await api.explain(chosen)
    setSimplified(res.text)
  }, [grade])

  const runVoice = useCallback(async () => {
    const res = await api.voiceTranslate(target)
    setVoiceResult({ spoken: res.spoken, translated: res.translated, responseTime: res.responseTime })
  }, [target])

  const runWorksheet = useCallback(
    async (opts: { count: number; target: LanguageCode; types: string[] }) => {
      const res = await api.generateWorksheet(opts)
      setWorksheet(res.questions as WorksheetQ[])
    },
    [],
  )

  const runFlashcards = useCallback(async () => {
    const res = await api.generateFlashcards(target)
    setFlashcards(res.cards)
  }, [target])

  const saveLesson = useCallback(
    (l: Omit<SavedLesson, 'id' | 'savedAt'>) => {
      const entry: SavedLesson = { ...l, id: crypto.randomUUID(), savedAt: Date.now() }
      persistSaved([entry, ...saved].slice(0, 30))
      toast('Lesson saved for offline access', 'success')
    },
    [saved, persistSaved, toast],
  )

  const removeSaved = useCallback(
    (id: string) => {
      persistSaved(saved.filter((s) => s.id !== id))
      toast('Resource removed', 'info')
    },
    [saved, persistSaved, toast],
  )

  /* --------------------------- full jury demo ---------------------------- */

  const skipDemo = useCallback(() => {
    demoAbort.current = true
    setDemoRunning(false)
    setDemoStep(0)
  }, [])

  const startFullDemo = useCallback(async () => {
    demoAbort.current = false
    setDemoRunning(true)
    const step = async (n: number, id: string, ms = 900) => {
      if (demoAbort.current) throw new Error('aborted')
      setDemoStep(n)
      scrollTo(id)
      await wait(ms)
    }
    try {
      // 1. sample image
      await step(1, 'scanner', 600)
      setImageState({ url: '/demo-textbook.png', name: 'demo-textbook.png', size: 184320, dimensions: '1024 × 768' })
      await wait(900)
      // 2. scan animation + extracted text
      await step(2, 'scanner', 200)
      await analyze()
      await wait(600)
      // 3. lesson understanding / simplify
      await step(3, 'simplifier', 400)
      await runSimplify(1)
      await wait(900)
      // 4. select santhali + translate
      await step(4, 'language-bridge', 400)
      setTarget('santhali')
      await runTranslate('गिनती कीजिए और सही संख्या लिखिए।')
      await wait(900)
      // 5. voice output
      await step(5, 'voice', 400)
      await runVoice()
      await wait(1000)
      // 6. worksheet
      await step(6, 'worksheets', 400)
      await runWorksheet({ count: 5, target: 'santhali', types: [] })
      await wait(900)
      // 7. flashcards
      await step(7, 'flashcards', 400)
      await runFlashcards()
      await wait(900)
      // 8. offline saved
      await step(8, 'offline', 400)
      setOfflinePersist(true)
      saveLesson({ topic: 'Numbers', language: 'Santhali', translated: 'ᱞᱮᱠᱷᱟ ᱮᱢ ᱯᱮ' })
      await wait(900)
      setDemoRunning(false)
      setDemoStep(0)
      toast('Lesson successfully converted into a multilingual learning resource.', 'success')
    } catch {
      /* aborted */
    }
  }, [analyze, runSimplify, runTranslate, runVoice, runWorksheet, runFlashcards, saveLesson, setOfflinePersist, toast])

  const value = useMemo<StoreValue>(
    () => ({
      toasts,
      toast,
      image,
      setImage,
      useDemoImage,
      scanning,
      scanProgress,
      scanStep,
      ocr,
      setOcrText,
      analyze,
      target,
      setTarget,
      translation,
      runTranslate,
      originalLesson: DEMO_ORIGINAL_LESSON,
      grade,
      simplified,
      runSimplify,
      voiceResult,
      runVoice,
      worksheet,
      runWorksheet,
      flashcards,
      runFlashcards,
      offline,
      setOffline: setOfflinePersist,
      saved,
      saveLesson,
      removeSaved,
      demoRunning,
      demoStep,
      demoTotal,
      startFullDemo,
      skipDemo,
    }),
    [
      toasts, toast, image, setImage, useDemoImage, scanning, scanProgress, scanStep, ocr,
      setOcrText, analyze, target, translation, runTranslate, grade, simplified, runSimplify,
      voiceResult, runVoice, worksheet, runWorksheet, flashcards, runFlashcards, offline,
      setOfflinePersist, saved, saveLesson, removeSaved, demoRunning, demoStep, startFullDemo, skipDemo,
    ],
  )

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>
}
