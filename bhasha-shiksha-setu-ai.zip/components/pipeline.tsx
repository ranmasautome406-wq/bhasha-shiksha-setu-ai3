import { ArrowRight, BookOpen, Camera, Globe, Layers, Volume2, WifiOff } from 'lucide-react'
import { SectionHeading } from './section'

const STAGES = [
  { icon: Camera, title: 'Capture', desc: 'Teacher photographs any textbook page' },
  { icon: BookOpen, title: 'Understand', desc: 'AI reads & grades the lesson content' },
  { icon: Globe, title: 'Translate', desc: 'Converted into the local mother tongue' },
  { icon: Volume2, title: 'Voice', desc: 'Text-to-speech for early readers' },
  { icon: Layers, title: 'Resources', desc: 'Worksheets & flashcards generated' },
  { icon: WifiOff, title: 'Offline', desc: 'Saved for zero-connectivity classrooms' },
]

export function Pipeline() {
  return (
    <section id="pipeline" className="scroll-mt-20 bg-foreground py-16 text-background sm:py-20">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="How It Works"
          title="One photo. A full multilingual lesson."
          subtitle="A six-stage AI pipeline turns a single textbook photograph into an inclusive, offline-ready teaching kit."
          invert
        />
        <ol className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-6">
          {STAGES.map((s, i) => {
            const Icon = s.icon
            return (
              <li key={s.title} className="relative flex flex-col items-center gap-3 text-center">
                <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-background/10 text-background ring-1 ring-background/20">
                  <Icon className="h-6 w-6" aria-hidden />
                </span>
                <div>
                  <p className="font-display text-sm font-bold">{`${i + 1}. ${s.title}`}</p>
                  <p className="mt-1 text-xs leading-relaxed text-background/70 text-balance">{s.desc}</p>
                </div>
                {i < STAGES.length - 1 ? (
                  <ArrowRight
                    className="absolute -right-3 top-4 hidden h-4 w-4 text-background/30 lg:block"
                    aria-hidden
                  />
                ) : null}
              </li>
            )
          })}
        </ol>
      </div>
    </section>
  )
}
