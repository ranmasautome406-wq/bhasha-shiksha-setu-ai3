'use client'

import { Rocket, X } from 'lucide-react'
import { useStore } from './store'
import { Button } from '@/components/ui/button'

const LABELS = [
  'Loading sample textbook',
  'Scanning & extracting text',
  'Understanding the lesson',
  'Translating to Santhali',
  'Generating voice output',
  'Building a worksheet',
  'Creating flashcards',
  'Saving for offline use',
]

export function DemoOverlay() {
  const { demoRunning, demoStep, demoTotal, skipDemo } = useStore()
  if (!demoRunning) return null

  return (
    <div className="fixed inset-x-0 bottom-4 z-50 flex justify-center px-4">
      <div
        role="status"
        aria-live="polite"
        className="flex w-full max-w-md items-center gap-4 rounded-2xl border border-border bg-card/95 p-4 shadow-xl backdrop-blur animate-fade-up"
      >
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground">
          <Rocket className="h-5 w-5 animate-pulse" aria-hidden />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between gap-2">
            <p className="font-display text-sm font-bold">Auto Demo Running</p>
            <span className="text-xs font-semibold text-muted-foreground">
              {demoStep}/{demoTotal}
            </span>
          </div>
          <p className="mt-0.5 truncate text-sm text-muted-foreground">
            {LABELS[Math.max(0, demoStep - 1)]}
          </p>
          <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-secondary">
            <div
              className="h-full rounded-full bg-primary transition-all duration-500"
              style={{ width: `${(demoStep / demoTotal) * 100}%` }}
            />
          </div>
        </div>
        <Button variant="ghost" size="icon" className="shrink-0" onClick={skipDemo} aria-label="Skip demo">
          <X className="h-4 w-4" aria-hidden />
        </Button>
      </div>
    </div>
  )
}
