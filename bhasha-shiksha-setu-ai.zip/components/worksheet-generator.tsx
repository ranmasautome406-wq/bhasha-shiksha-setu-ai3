'use client'

import { useState } from 'react'
import { Download, Printer, RefreshCw, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { SectionHeading, DemoBadge } from './section'
import { useStore } from './store'
import { TARGET_LANGUAGES, type LanguageCode } from '@/lib/demo-data'
import { cn } from '@/lib/utils'

const TYPES = ['MCQ', 'Fill in the blanks', 'Match the following', 'Short answer']

export function WorksheetGenerator() {
  const { worksheet, runWorksheet, target, setTarget, toast } = useStore()
  const [count, setCount] = useState(5)
  const [types, setTypes] = useState<string[]>([...TYPES])
  const [busy, setBusy] = useState(false)

  function toggleType(t: string) {
    setTypes((prev) => (prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]))
  }

  async function generate() {
    setBusy(true)
    await runWorksheet({ count, target, types })
    setBusy(false)
    toast('Worksheet generated', 'success')
  }

  const targetLabel = TARGET_LANGUAGES.find((l) => l.code === target)?.label ?? 'Santhali'

  return (
    <section id="worksheets" className="scroll-mt-20 bg-secondary/40 py-16 sm:py-20">
      <div className="mx-auto max-w-5xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Worksheet Builder"
          title="AI Bilingual Worksheet Generator"
          subtitle="Create bilingual learning activities — Hindi alongside the mother tongue — in one click."
        />

        <div className="mt-10 grid gap-6 lg:grid-cols-[320px_1fr]">
          {/* Controls */}
          <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-5">
            <Row label="Subject">
              <input
                defaultValue="Mathematics"
                aria-label="Subject"
                className="w-full rounded-lg border border-border bg-secondary/40 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
              />
            </Row>
            <div className="grid grid-cols-2 gap-3">
              <Row label="Class">
                <input
                  defaultValue="1"
                  aria-label="Class"
                  className="w-full rounded-lg border border-border bg-secondary/40 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
                />
              </Row>
              <Row label="Topic">
                <input
                  defaultValue="Numbers"
                  aria-label="Topic"
                  className="w-full rounded-lg border border-border bg-secondary/40 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
                />
              </Row>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Row label="Source">
                <input
                  defaultValue="Hindi"
                  readOnly
                  aria-label="Source language"
                  className="w-full rounded-lg border border-border bg-secondary/40 px-3 py-2 text-sm outline-none"
                />
              </Row>
              <Row label="Target">
                <select
                  value={target}
                  onChange={(e) => setTarget(e.target.value as LanguageCode)}
                  aria-label="Target language"
                  className="w-full rounded-lg border border-border bg-secondary/40 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
                >
                  {TARGET_LANGUAGES.map((l) => (
                    <option key={l.code} value={l.code}>
                      {l.label}
                    </option>
                  ))}
                </select>
              </Row>
            </div>

            <Row label="Number of Questions">
              <div className="flex gap-2">
                {[5, 10, 15].map((n) => (
                  <button
                    key={n}
                    onClick={() => setCount(n)}
                    className={cn(
                      'flex-1 rounded-lg border px-3 py-2 text-sm font-semibold transition-colors',
                      count === n
                        ? 'border-primary bg-primary text-primary-foreground'
                        : 'border-border bg-secondary/40 hover:bg-secondary',
                    )}
                  >
                    {n}
                  </button>
                ))}
              </div>
            </Row>

            <Row label="Question Types">
              <div className="flex flex-col gap-2">
                {TYPES.map((t) => (
                  <label key={t} className="flex cursor-pointer items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={types.includes(t)}
                      onChange={() => toggleType(t)}
                      className="h-4 w-4 accent-[var(--primary)]"
                    />
                    {t}
                  </label>
                ))}
              </div>
            </Row>

            <Button className="mt-1 gap-2" onClick={generate} disabled={busy}>
              <Sparkles className="h-4 w-4" aria-hidden />
              {busy ? 'Generating…' : 'Generate Worksheet'}
            </Button>
          </div>

          {/* Output */}
          <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-5">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold">
                Mathematics · Class 1 · Numbers
              </h3>
              {worksheet ? <DemoBadge>Demo Worksheet</DemoBadge> : null}
            </div>

            {worksheet ? (
              <>
                <ol className="flex flex-col gap-3">
                  {worksheet.map((q, i) => (
                    <li key={q.id} className="rounded-xl border border-border bg-secondary/30 p-4 animate-fade-up">
                      <div className="flex items-start justify-between gap-3">
                        <p className="font-semibold">
                          <span className="mr-2 text-primary">{i + 1}.</span>
                          <span lang="hi">{q.hindi}</span>
                        </p>
                        <span className="shrink-0 rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-bold text-primary">
                          {q.type}
                        </span>
                      </div>
                      <p className="mt-1 pl-6 text-sm text-muted-foreground">
                        {targetLabel}: {q.target}
                      </p>
                      {q.options.length > 0 ? (
                        <ul className="mt-2 grid grid-cols-2 gap-2 pl-6 text-sm">
                          {q.options.map((o) => (
                            <li key={o} className="rounded-lg border border-border bg-card px-3 py-1.5">
                              {o}
                            </li>
                          ))}
                        </ul>
                      ) : null}
                    </li>
                  ))}
                </ol>
                <div className="flex flex-wrap gap-2">
                  <Button variant="outline" className="gap-2" onClick={() => window.print()}>
                    <Printer className="h-4 w-4" aria-hidden />
                    Print
                  </Button>
                  <Button
                    variant="outline"
                    className="gap-2"
                    onClick={() => downloadWorksheet(worksheet, targetLabel)}
                  >
                    <Download className="h-4 w-4" aria-hidden />
                    Download
                  </Button>
                  <Button variant="outline" className="gap-2" onClick={generate} disabled={busy}>
                    <RefreshCw className="h-4 w-4" aria-hidden />
                    Regenerate
                  </Button>
                </div>
              </>
            ) : (
              <div className="flex flex-1 items-center justify-center rounded-xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
                Configure the worksheet and press Generate to see questions here.
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-xs font-semibold text-muted-foreground">{label}</span>
      {children}
    </label>
  )
}

function downloadWorksheet(
  questions: { id: number; type: string; hindi: string; target: string; options: string[] }[],
  targetLabel: string,
) {
  const lines = questions.map(
    (q, i) =>
      `${i + 1}. [${q.type}] ${q.hindi}\n   ${targetLabel}: ${q.target}${
        q.options.length ? `\n   Options: ${q.options.join(', ')}` : ''
      }`,
  )
  const content = `Bhasha Shiksha Setu AI — Bilingual Worksheet\nMathematics · Class 1 · Numbers\n(Demo prototype output)\n\n${lines.join('\n\n')}\n`
  const blob = new Blob([content], { type: 'text/plain' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = 'worksheet.txt'
  a.click()
  URL.revokeObjectURL(url)
}
