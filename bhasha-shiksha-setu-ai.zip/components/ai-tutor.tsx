'use client'

import { useRef, useState } from 'react'
import { Bot, Send, Sparkles, User } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { SectionHeading } from './section'
import { chat } from '@/lib/api'
import { cn } from '@/lib/utils'

type Msg = { role: 'user' | 'ai'; text: string }

const SUGGESTIONS = ['Explain this lesson', 'Give me an example', 'Ask me a question', 'Help with homework']

export function AiTutor() {
  const [messages, setMessages] = useState<Msg[]>([
    { role: 'ai', text: 'Namaste! I am Bhasha AI Tutor. Ask me anything about your lesson — try "What is 2 + 3?"' },
  ])
  const [input, setInput] = useState('')
  const [thinking, setThinking] = useState(false)
  const listRef = useRef<HTMLDivElement>(null)

  async function send(text: string) {
    const q = text.trim()
    if (!q || thinking) return
    setMessages((m) => [...m, { role: 'user', text: q }])
    setInput('')
    setThinking(true)
    const res = await chat(q)
    setMessages((m) => [...m, { role: 'ai', text: res.reply }])
    setThinking(false)
    requestAnimationFrame(() => {
      listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' })
    })
  }

  function onKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'Enter' && !e.shiftKey) {
      if ((e.nativeEvent as any).isComposing || (e as any).keyCode === 229) return
      e.preventDefault()
      send(input)
    }
  }

  return (
    <section id="tutor" className="scroll-mt-20 bg-secondary/40 py-16 sm:py-20">
      <div className="mx-auto max-w-3xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="AI Tutor"
          title="Bhasha AI Tutor"
          subtitle="Ask questions in the language you understand."
        />

        <div className="mt-10 flex flex-col overflow-hidden rounded-3xl border border-border bg-card shadow-sm">
          <div className="flex items-center gap-3 border-b border-border bg-primary/5 px-5 py-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground">
              <Bot className="h-5 w-5" aria-hidden />
            </span>
            <div>
              <p className="font-display text-sm font-bold">Bhasha AI Tutor</p>
              <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <span className="h-1.5 w-1.5 rounded-full bg-accent" /> Online · Demo assistant
              </p>
            </div>
          </div>

          <div ref={listRef} className="flex max-h-96 flex-col gap-3 overflow-y-auto p-5" aria-live="polite">
            {messages.map((m, i) => (
              <div
                key={i}
                className={cn('flex items-end gap-2', m.role === 'user' ? 'flex-row-reverse' : 'flex-row')}
              >
                <span
                  className={cn(
                    'flex h-7 w-7 shrink-0 items-center justify-center rounded-full',
                    m.role === 'user' ? 'bg-accent text-accent-foreground' : 'bg-primary text-primary-foreground',
                  )}
                >
                  {m.role === 'user' ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                </span>
                <p
                  className={cn(
                    'max-w-[78%] text-pretty rounded-2xl px-4 py-2.5 text-sm leading-relaxed',
                    m.role === 'user'
                      ? 'rounded-br-sm bg-primary text-primary-foreground'
                      : 'rounded-bl-sm bg-secondary',
                  )}
                >
                  {m.text}
                </p>
              </div>
            ))}
            {thinking ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-primary text-primary-foreground">
                  <Bot className="h-4 w-4" />
                </span>
                <span className="flex gap-1 rounded-2xl bg-secondary px-4 py-3">
                  <Dot /> <Dot delay="0.15s" /> <Dot delay="0.3s" />
                </span>
              </div>
            ) : null}
          </div>

          <div className="flex flex-wrap gap-2 border-t border-border px-5 pt-4">
            {SUGGESTIONS.map((s) => (
              <button
                key={s}
                onClick={() => send(s)}
                className="inline-flex items-center gap-1.5 rounded-full border border-primary/25 bg-primary/5 px-3 py-1.5 text-xs font-medium text-primary transition-colors hover:bg-primary/10"
              >
                <Sparkles className="h-3 w-3" aria-hidden />
                {s}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 p-4">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={onKeyDown}
              placeholder="Ask your question..."
              aria-label="Ask the AI tutor a question"
              className="flex-1 rounded-full border border-border bg-secondary/40 px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-ring"
            />
            <Button size="icon" className="h-11 w-11 shrink-0 rounded-full" aria-label="Send" onClick={() => send(input)}>
              <Send className="h-5 w-5" aria-hidden />
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

function Dot({ delay = '0s' }: { delay?: string }) {
  return (
    <span
      className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground/60"
      style={{ animationDelay: delay }}
    />
  )
}
