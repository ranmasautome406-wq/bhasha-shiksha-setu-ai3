import { Check } from 'lucide-react'
import { SectionHeading } from './section'

const POINTS = [
  {
    title: 'Problem Statement Fit',
    body: 'Directly addresses multilingual, inclusive education for rural and tribal learners under the Smart Education theme.',
  },
  {
    title: 'NEP 2020 Aligned',
    body: 'Supports mother-tongue / regional-language instruction in the foundational years, as recommended by the National Education Policy.',
  },
  {
    title: 'Low-Resource Ready',
    body: 'Works on a basic smartphone, needs no special hardware, and functions fully offline after a lesson is saved.',
  },
  {
    title: 'Scalable & Extensible',
    body: 'New languages and subjects plug into the same pipeline — one model serves thousands of single-teacher schools.',
  },
  {
    title: 'Measurable Impact',
    body: 'Every scan produces reusable worksheets and flashcards, multiplying a single teacher’s reach.',
  },
  {
    title: 'Feasible Prototype',
    body: 'This working prototype demonstrates the full capture-to-classroom journey end to end.',
  },
]

export function SihAlignment() {
  return (
    <section id="sih" className="scroll-mt-20 bg-secondary/40 py-16 sm:py-20">
      <div className="mx-auto max-w-5xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Smart India Hackathon"
          title="Built for the judging criteria"
          subtitle="Bhasha Setu maps cleanly to the SIH evaluation rubric — from problem fit to feasibility."
        />
        <div className="mt-10 grid gap-4 sm:grid-cols-2">
          {POINTS.map((p) => (
            <div key={p.title} className="flex gap-3 rounded-2xl border border-border bg-card p-5">
              <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-accent text-accent-foreground">
                <Check className="h-3.5 w-3.5" aria-hidden />
              </span>
              <div>
                <p className="font-display font-bold">{p.title}</p>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground text-pretty">{p.body}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
