import { SectionHeading } from './section'

const STATS = [
  { value: '19,500+', label: 'Mother tongues spoken across India', sub: 'yet textbooks reach few of them' },
  { value: '25%', label: 'of children learn in their home language', sub: 'the rest face a language barrier at school' },
  { value: '1.5M', label: 'schools in India, many rural & remote', sub: 'often with a single teacher per grade' },
  { value: '0', label: 'internet needed after a lesson is saved', sub: 'built for low-connectivity classrooms' },
]

export function Impact() {
  return (
    <section id="impact" className="scroll-mt-20 py-16 sm:py-20">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Why It Matters"
          title="Language should never decide who gets to learn"
          subtitle="Millions of first-generation learners fall behind simply because lessons arrive in an unfamiliar language. Bhasha Setu closes that gap."
        />
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {STATS.map((s) => (
            <div key={s.label} className="flex flex-col gap-2 rounded-2xl border border-border bg-card p-6">
              <p className="font-display text-4xl font-extrabold text-primary">{s.value}</p>
              <p className="font-semibold leading-tight text-pretty">{s.label}</p>
              <p className="text-sm text-muted-foreground text-pretty">{s.sub}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
