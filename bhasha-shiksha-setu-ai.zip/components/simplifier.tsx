'use client'

import { useState } from 'react'
import { Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { SectionHeading } from './section'
import { useStore } from './store'
import { cn } from '@/lib/utils'

export function Simplifier() {
  const { originalLesson, grade, simplified, runSimplify } = useStore()
  const [busy, setBusy] = useState(false)

  async function simplify(g?: 1 | 2 | 3) {
    setBusy(true)
    await runSimplify(g)
    setBusy(false)
  }

  return (
    <section id="simplifier" className="scroll-mt-20 bg-secondary/40 py-16 sm:py-20">
      <div className="mx-auto max-w-5xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Adaptive Learning"
          title="AI Lesson Simplifier"
          subtitle="Rewrite dense textbook language into explanations suited to a child's grade level."
        />

        <div className="mt-10 grid gap-4 lg:grid-cols-2">
          <div className="flex flex-col gap-2 rounded-2xl border border-border bg-card p-5">
            <span className="text-sm font-semibold text-muted-foreground">Original Lesson</span>
            <p className="leading-relaxed text-pretty" lang="hi">
              {originalLesson}
            </p>
          </div>

          <div className="flex flex-col gap-3 rounded-2xl border border-accent/40 bg-accent/5 p-5">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-muted-foreground">Child-Friendly Explanation</span>
              <div className="flex gap-1">
                {([1, 2, 3] as const).map((g) => (
                  <button
                    key={g}
                    onClick={() => simplify(g)}
                    className={cn(
                      'rounded-lg px-3 py-1.5 text-xs font-bold transition-colors',
                      grade === g && simplified
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-card text-foreground/70 hover:bg-secondary',
                    )}
                  >
                    Grade {g}
                  </button>
                ))}
              </div>
            </div>
            <p className="min-h-24 rounded-xl bg-card p-4 leading-relaxed text-pretty">
              {simplified ?? 'Choose a grade or press Simplify Lesson to generate a child-friendly version.'}
            </p>
            <Button className="mt-auto gap-2" onClick={() => simplify()} disabled={busy}>
              <Sparkles className="h-4 w-4" aria-hidden />
              {busy ? 'Simplifying…' : 'Simplify Lesson'}
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
