'use client'

import { useEffect, useState } from 'react'
import { Languages, Menu, UserCircle2, X } from 'lucide-react'
import { cn } from '@/lib/utils'

const LINKS = [
  { label: 'Home', id: 'home' },
  { label: 'AI Scanner', id: 'scanner' },
  { label: 'Voice Classroom', id: 'voice' },
  { label: 'Worksheets', id: 'worksheets' },
  { label: 'Flashcards', id: 'flashcards' },
  { label: 'AI Tutor', id: 'tutor' },
  { label: 'Dashboard', id: 'dashboard' },
]

export function SiteNav() {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const go = (id: string) => {
    setOpen(false)
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  return (
    <header
      className={cn(
        'sticky top-0 z-50 w-full transition-all',
        scrolled ? 'glass border-b border-border/70 shadow-sm' : 'bg-transparent',
      )}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
        <button
          onClick={() => go('home')}
          className="flex items-center gap-2.5 rounded-lg outline-none focus-visible:ring-2 focus-visible:ring-ring"
          aria-label="Bhasha Shiksha Setu AI home"
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-md">
            <Languages className="h-5 w-5" aria-hidden />
          </span>
          <span className="flex flex-col leading-none">
            <span className="font-display text-sm font-bold tracking-tight sm:text-base">
              Bhasha Shiksha Setu <span className="text-primary">AI</span>
            </span>
            <span className="hidden text-[10px] font-medium text-muted-foreground sm:block">
              Bridging Languages. Empowering Classrooms.
            </span>
          </span>
        </button>

        <ul className="hidden items-center gap-1 lg:flex">
          {LINKS.map((l) => (
            <li key={l.id}>
              <button
                onClick={() => go(l.id)}
                className="rounded-lg px-3 py-2 text-sm font-medium text-foreground/70 transition-colors hover:bg-secondary hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring"
              >
                {l.label}
              </button>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          <span className="hidden items-center gap-2 rounded-full border border-accent/40 bg-accent/10 px-3 py-1.5 text-xs font-semibold text-accent-foreground sm:flex">
            <span className="h-2 w-2 rounded-full bg-accent" />
            Teacher Mode
          </span>
          <button
            aria-label="Teacher profile"
            className="flex h-9 w-9 items-center justify-center rounded-full bg-secondary text-foreground/70 transition-colors hover:bg-secondary/70"
          >
            <UserCircle2 className="h-6 w-6" aria-hidden />
          </button>
          <button
            aria-label={open ? 'Close menu' : 'Open menu'}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
            className="flex h-9 w-9 items-center justify-center rounded-lg bg-secondary text-foreground lg:hidden"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </nav>

      {open ? (
        <div className="border-t border-border/70 glass lg:hidden">
          <ul className="mx-auto flex max-w-7xl flex-col gap-1 px-4 py-3">
            {LINKS.map((l) => (
              <li key={l.id}>
                <button
                  onClick={() => go(l.id)}
                  className="w-full rounded-lg px-3 py-3 text-left text-base font-medium text-foreground/80 transition-colors hover:bg-secondary"
                >
                  {l.label}
                </button>
              </li>
            ))}
            <li className="mt-1 flex items-center gap-2 rounded-full border border-accent/40 bg-accent/10 px-3 py-2 text-sm font-semibold text-accent-foreground">
              <span className="h-2 w-2 rounded-full bg-accent" />
              Teacher Mode
            </li>
          </ul>
        </div>
      ) : null}
    </header>
  )
}
