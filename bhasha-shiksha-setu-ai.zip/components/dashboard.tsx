'use client'

import { BookMarked, Trash2, Volume2, WifiOff } from 'lucide-react'
import { SectionHeading } from './section'
import { useStore } from './store'
import { Button } from '@/components/ui/button'
import { speak } from '@/lib/speech'

export function Dashboard() {
  const { saved, removeSaved, toast, offline } = useStore()

  return (
    <section id="dashboard" className="scroll-mt-20 py-16 sm:py-20">
      <div className="mx-auto max-w-5xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Teacher Workspace"
          title="Saved Lessons"
          subtitle="Every lesson you convert is collected here — available even without internet."
        />

        <div className="mt-10">
          {saved.length === 0 ? (
            <div className="flex flex-col items-center gap-3 rounded-3xl border border-dashed border-border bg-card p-12 text-center">
              <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-secondary text-muted-foreground">
                <BookMarked className="h-7 w-7" aria-hidden />
              </span>
              <p className="font-display text-lg font-bold">No saved lessons yet</p>
              <p className="max-w-sm text-sm text-muted-foreground">
                Translate a lesson and save it to build your offline teaching library.
              </p>
            </div>
          ) : (
            <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {saved.map((item) => (
                <li
                  key={item.id}
                  className="flex flex-col gap-3 rounded-2xl border border-border bg-card p-5 animate-fade-up"
                >
                  <div className="flex items-start justify-between">
                    <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                      <BookMarked className="h-5 w-5" aria-hidden />
                    </span>
                    <span className="rounded-full bg-accent/15 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-accent-foreground">
                      {item.language}
                    </span>
                  </div>
                  <div className="min-w-0">
                    <p className="font-display font-bold leading-tight text-pretty">{item.topic}</p>
                    <p className="mt-1 line-clamp-2 text-lg text-muted-foreground">{item.translated}</p>
                    <p className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
                      {offline ? <WifiOff className="h-3 w-3" aria-hidden /> : null}
                      Saved {new Date(item.savedAt).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="mt-auto flex items-center gap-2 pt-1">
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-8 gap-1.5 text-xs"
                      onClick={() => {
                        speak(item.translated, item.language === 'Hindi' ? 'hi-IN' : 'en-IN')
                        toast('Playing audio', 'success')
                      }}
                    >
                      <Volume2 className="h-3.5 w-3.5" aria-hidden />
                      Listen
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="ml-auto h-8 gap-1.5 text-xs text-destructive hover:bg-destructive/10 hover:text-destructive"
                      onClick={() => removeSaved(item.id)}
                    >
                      <Trash2 className="h-3.5 w-3.5" aria-hidden />
                      Remove
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </section>
  )
}
