'use client'

import { ArrowRight, Camera, Mic, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'

const BADGES = ['Mother-Tongue Learning', 'AI-Assisted', 'Teacher Friendly', 'Offline Ready']

function go(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
}

export function Hero() {
  return (
    <section id="home" className="relative overflow-hidden">
      {/* soft background wash */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10"
        style={{
          background:
            'radial-gradient(60% 55% at 15% 0%, color-mix(in oklch, var(--primary) 14%, transparent), transparent), radial-gradient(50% 50% at 95% 10%, color-mix(in oklch, var(--accent) 18%, transparent), transparent)',
        }}
      />
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-24">
        <div className="flex flex-col items-start gap-6">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-3 py-1.5 text-xs font-semibold text-primary">
            <Sparkles className="h-3.5 w-3.5" aria-hidden />
            SIH26042 · Smart Education · Govt. of Jharkhand
          </span>
          <h1 className="font-display text-4xl font-extrabold leading-[1.05] tracking-tight text-balance sm:text-5xl lg:text-6xl">
            Teach Every Child in the Language They{' '}
            <span className="text-gradient">Understand.</span>
          </h1>
          <p className="text-lg font-medium text-foreground/80">
            AI-powered vernacular education for mother-tongue-based primary learning.
          </p>
          <p className="max-w-xl text-pretty leading-relaxed text-muted-foreground">
            Bhasha Shiksha Setu AI helps teachers transform Hindi educational content into
            multilingual learning experiences using AI-assisted lesson scanning, simplification,
            translation, voice interaction, worksheets and visual learning.
          </p>

          <div className="flex flex-col gap-3 sm:flex-row">
            <Button size="lg" className="h-12 gap-2 px-6 text-base shadow-lg" onClick={() => go('scanner')}>
              <Camera className="h-5 w-5" aria-hidden />
              Scan a Lesson
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="h-12 gap-2 border-primary/30 px-6 text-base"
              onClick={() => go('voice')}
            >
              <Mic className="h-5 w-5" aria-hidden />
              Start Voice Classroom
            </Button>
          </div>

          <ul className="flex flex-wrap gap-2 pt-2">
            {BADGES.map((b) => (
              <li
                key={b}
                className="inline-flex items-center gap-1.5 rounded-full border border-accent/40 bg-accent/10 px-3 py-1.5 text-xs font-semibold text-accent-foreground"
              >
                <span className="text-accent">✓</span>
                {b}
              </li>
            ))}
          </ul>
        </div>

        <HeroPreview />
      </div>
    </section>
  )
}

function HeroPreview() {
  return (
    <div className="relative">
      <div className="animate-float glass rounded-3xl border border-border/70 p-5 shadow-xl">
        <div className="flex items-center justify-between pb-4">
          <span className="text-xs font-semibold text-muted-foreground">Live pipeline preview</span>
          <span className="flex items-center gap-1.5 text-xs font-semibold text-accent-foreground">
            <span className="h-2 w-2 animate-pulse rounded-full bg-accent" /> Processing
          </span>
        </div>

        <div className="flex flex-col gap-3">
          {/* Hindi textbook */}
          <div className="rounded-2xl border border-border bg-card p-4">
            <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
              Hindi Textbook
            </p>
            <p className="mt-1 font-display text-lg font-semibold" lang="hi">
              गिनती कीजिए और सही संख्या लिखिए।
            </p>
          </div>

          {/* AI node */}
          <div className="flex items-center justify-center">
            <span className="flex items-center gap-2 rounded-full bg-primary px-4 py-1.5 text-xs font-bold text-primary-foreground shadow-md">
              <Sparkles className="h-3.5 w-3.5" aria-hidden /> AI
            </span>
          </div>

          {/* Target languages */}
          <div className="grid grid-cols-3 gap-2">
            {[
              { l: 'Ho', t: 'Lekha em pe' },
              { l: 'Mundari', t: 'Lekha em pe' },
              { l: 'Santhali', t: 'ᱞᱮᱠᱷᱟ ᱮᱢ ᱯᱮ' },
            ].map((x) => (
              <div key={x.l} className="rounded-xl border border-accent/30 bg-accent/10 p-3 text-center">
                <p className="text-[11px] font-bold text-accent-foreground">{x.l}</p>
                <p className="mt-1 truncate text-xs text-foreground/70">{x.t}</p>
              </div>
            ))}
          </div>

          {/* Child-friendly */}
          <div className="flex items-center gap-3 rounded-2xl border border-border bg-secondary/60 p-4">
            <span className="text-2xl" aria-hidden>🧒</span>
            <p className="text-sm font-medium">
              Child-Friendly Lesson: <span className="text-muted-foreground">Let&apos;s count together — 1, 2, 3!</span>
            </p>
          </div>
        </div>
      </div>

      <div className="absolute -bottom-4 -right-2 hidden items-center gap-2 rounded-2xl border border-border bg-card px-4 py-3 shadow-lg sm:flex">
        <ArrowRight className="h-4 w-4 text-primary" aria-hidden />
        <span className="text-xs font-semibold">Textbook → Mother Tongue in seconds</span>
      </div>
    </div>
  )
}
