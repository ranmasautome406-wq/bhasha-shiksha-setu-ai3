'use client'

import { useState } from 'react'
import { ChevronLeft, ChevronRight, Sparkles, Volume2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { SectionHeading, DemoBadge } from './section'
import { useStore } from './store'
import { TARGET_LANGUAGES } from '@/lib/demo-data'
import { speak } from '@/lib/speech'

export function Flashcards() {
  const { flashcards, runFlashcards, target, toast } = useStore()
  const [busy, setBusy] = useState(false)
  const [index, setIndex] = useState(0)

  const targetLabel = TARGET_LANGUAGES.find((l) => l.code === target)?.label ?? 'Santhali'

  async function generate() {
    setBusy(true)
    await runFlashcards()
    setIndex(0)
    setBusy(false)
    toast('Flashcards generated', 'success')
  }

  return (
    <section id="flashcards" className="scroll-mt-20 py-16 sm:py-20">
      <div className="mx-auto max-w-5xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Visual Learning"
          title="Visual Learning Flashcards"
          subtitle="Picture-first vocabulary cards pairing Hindi with the mother tongue and pronunciation."
        />

        <div className="mt-8 flex justify-center">
          <Button className="gap-2 px-6" onClick={generate} disabled={busy}>
            <Sparkles className="h-4 w-4" aria-hidden />
            {busy ? 'Generating…' : 'Generate Flashcards'}
          </Button>
        </div>

        {flashcards ? (
          <div className="mt-8 flex flex-col gap-5">
            <div className="flex items-center justify-between">
              <DemoBadge>Demo Vocabulary</DemoBadge>
              <span className="text-sm text-muted-foreground">
                {index + 1} / {flashcards.length}
              </span>
            </div>

            {/* Horizontal carousel */}
            <div className="-mx-4 flex snap-x snap-mandatory gap-4 overflow-x-auto px-4 pb-4 [scrollbar-width:thin]">
              {flashcards.map((c, i) => (
                <article
                  key={c.hindi}
                  className="flex w-56 shrink-0 snap-center flex-col items-center gap-3 rounded-3xl border border-border bg-card p-6 text-center shadow-sm transition-transform hover:-translate-y-1"
                  onFocus={() => setIndex(i)}
                  onMouseEnter={() => setIndex(i)}
                >
                  <span className="text-6xl" aria-hidden>
                    {c.emoji}
                  </span>
                  <span className="sr-only">{c.target}</span>
                  <p className="font-display text-xl font-bold" lang="hi">
                    {c.hindi}
                  </p>
                  <div className="w-full rounded-xl bg-accent/10 p-3">
                    <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                      {targetLabel}
                    </p>
                    <p className="font-display text-lg text-accent-foreground">{c.target}</p>
                  </div>
                  <p className="text-sm text-muted-foreground">/ {c.pronunciation} /</p>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="gap-1.5 text-primary"
                    onClick={() => speak(c.hindi, 'hi-IN')}
                  >
                    <Volume2 className="h-4 w-4" aria-hidden />
                    Pronounce
                  </Button>
                </article>
              ))}
            </div>

            <div className="flex items-center justify-center gap-3">
              <Button
                variant="outline"
                size="icon"
                aria-label="Previous card"
                onClick={() => setIndex((i) => Math.max(0, i - 1))}
              >
                <ChevronLeft className="h-5 w-5" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                aria-label="Next card"
                onClick={() => setIndex((i) => Math.min(flashcards.length - 1, i + 1))}
              >
                <ChevronRight className="h-5 w-5" />
              </Button>
            </div>
          </div>
        ) : (
          <p className="mt-8 text-center text-sm text-muted-foreground">
            Press Generate Flashcards to build a visual vocabulary set.
          </p>
        )}
      </div>
    </section>
  )
}
