'use client'

import { useRef, useState } from 'react'
import {
  BookOpen,
  Brain,
  Camera,
  Globe,
  Image as ImageIcon,
  Pencil,
  ScanText,
  Search,
  Trash2,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { SectionHeading, DemoBadge } from './section'
import { useStore } from './store'
import { cn } from '@/lib/utils'

const STEPS = [
  { icon: Camera, label: 'Reading Image' },
  { icon: Search, label: 'Extracting Text' },
  { icon: Brain, label: 'Understanding Lesson' },
  { icon: Globe, label: 'Preparing Translation' },
  { icon: BookOpen, label: 'Creating Learning Resources' },
]

const ACCEPT = 'image/jpeg,image/jpg,image/png,image/webp'

export function Scanner() {
  const { image, setImage, useDemoImage, scanning, scanProgress, scanStep, ocr, setOcrText, analyze, toast } =
    useStore()
  const inputRef = useRef<HTMLInputElement>(null)
  const [dragging, setDragging] = useState(false)
  const [editing, setEditing] = useState(false)

  function loadFile(file: File) {
    if (!ACCEPT.includes(file.type)) {
      toast('Please upload a JPG, PNG or WEBP image', 'error')
      return
    }
    const url = URL.createObjectURL(file)
    const img = new window.Image()
    img.onload = () => {
      setImage({
        url,
        name: file.name,
        size: file.size,
        dimensions: `${img.naturalWidth} × ${img.naturalHeight}`,
      })
      toast('Image ready — click Analyze with AI', 'success')
    }
    img.src = url
  }

  function onDrop(e: React.DragEvent) {
    e.preventDefault()
    setDragging(false)
    const file = e.dataTransfer.files?.[0]
    if (file) loadFile(file)
  }

  return (
    <section id="scanner" className="scroll-mt-20 bg-secondary/40 py-16 sm:py-20">
      <div className="mx-auto max-w-5xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Main Feature"
          title="AI Lesson Scanner"
          subtitle="Turn a textbook photograph into a ready-to-teach multilingual lesson."
        />

        <div className="mt-10 grid gap-6 lg:grid-cols-2">
          {/* Upload / preview */}
          <div className="flex flex-col gap-4">
            {!image ? (
              <div
                onDragOver={(e) => {
                  e.preventDefault()
                  setDragging(true)
                }}
                onDragLeave={() => setDragging(false)}
                onDrop={onDrop}
                className={cn(
                  'flex flex-col items-center justify-center gap-3 rounded-3xl border-2 border-dashed p-10 text-center transition-colors',
                  dragging ? 'border-primary bg-primary/5' : 'border-border bg-card',
                )}
              >
                <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                  <ImageIcon className="h-7 w-7" aria-hidden />
                </span>
                <p className="font-display text-lg font-bold">Upload Textbook / Worksheet</p>
                <p className="text-sm text-muted-foreground">
                  Drag &amp; drop, or choose a photo · JPG, JPEG, PNG, WEBP
                </p>
                <div className="mt-2 flex flex-col gap-2 sm:flex-row">
                  <Button className="gap-2" onClick={() => inputRef.current?.click()}>
                    <Camera className="h-4 w-4" aria-hidden />
                    Choose Photo
                  </Button>
                  <Button variant="outline" className="border-primary/30" onClick={useDemoImage}>
                    Use Demo Image
                  </Button>
                </div>
                <input
                  ref={inputRef}
                  type="file"
                  accept={ACCEPT}
                  capture="environment"
                  className="sr-only"
                  aria-label="Upload textbook photo"
                  onChange={(e) => {
                    const file = e.target.files?.[0]
                    if (file) loadFile(file)
                  }}
                />
              </div>
            ) : (
              <div className="flex flex-col gap-4 rounded-3xl border border-border bg-card p-4">
                <div className="overflow-hidden rounded-2xl border border-border">
                  {/* Uploaded image really appears here */}
                  <img
                    src={image.url || '/placeholder.svg'}
                    alt={`Uploaded textbook page: ${image.name}`}
                    className="max-h-72 w-full object-contain bg-secondary"
                  />
                </div>
                <div className="flex flex-wrap items-center justify-between gap-3 text-sm">
                  <div className="min-w-0">
                    <p className="truncate font-semibold">{image.name}</p>
                    <p className="text-muted-foreground">
                      {(image.size / 1024).toFixed(0)} KB
                      {image.dimensions ? ` · ${image.dimensions}px` : ''}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="gap-1.5 text-destructive hover:bg-destructive/10 hover:text-destructive"
                    onClick={() => setImage(null)}
                  >
                    <Trash2 className="h-4 w-4" aria-hidden />
                    Remove
                  </Button>
                </div>
                <Button
                  size="lg"
                  className="h-12 w-full gap-2 text-base shadow-md"
                  onClick={analyze}
                  disabled={scanning}
                >
                  <ScanText className="h-5 w-5" aria-hidden />
                  {scanning ? 'Analyzing…' : 'Analyze with AI'}
                </Button>
              </div>
            )}
          </div>

          {/* Pipeline + OCR result */}
          <div className="flex flex-col gap-4 rounded-3xl border border-border bg-card p-5">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold">AI Analysis Pipeline</h3>
              {ocr ? (
                <span className="text-xs font-semibold text-accent-foreground">Complete</span>
              ) : null}
            </div>

            {/* progress bar */}
            <div className="h-2 w-full overflow-hidden rounded-full bg-secondary">
              <div
                className="h-full rounded-full bg-primary transition-all duration-150"
                style={{ width: `${ocr ? 100 : scanProgress}%` }}
              />
            </div>

            <ol className="flex flex-col gap-2">
              {STEPS.map((s, i) => {
                const Icon = s.icon
                const active = scanning && scanStep === i + 1
                const done = ocr || (scanning && scanStep > i + 1) || (scanProgress >= (i + 1) * 20)
                return (
                  <li
                    key={s.label}
                    className={cn(
                      'flex items-center gap-3 rounded-xl border px-3 py-2.5 text-sm transition-all',
                      active && 'border-primary bg-primary/5',
                      done && !active && 'border-accent/40 bg-accent/5',
                      !active && !done && 'border-border',
                    )}
                  >
                    <span
                      className={cn(
                        'flex h-8 w-8 items-center justify-center rounded-lg',
                        active ? 'bg-primary text-primary-foreground' : done ? 'bg-accent text-accent-foreground' : 'bg-secondary text-muted-foreground',
                      )}
                    >
                      <Icon className={cn('h-4 w-4', active && 'animate-pulse')} aria-hidden />
                    </span>
                    <span className="font-medium">{s.label}</span>
                    {done && !active ? <span className="ml-auto text-accent">✓</span> : null}
                  </li>
                )
              })}
            </ol>

            {ocr ? (
              <div className="mt-1 flex flex-col gap-3 rounded-2xl border border-border bg-secondary/40 p-4 animate-fade-up">
                <div className="flex items-center justify-between">
                  <p className="font-display text-sm font-bold text-accent-foreground">AI Analysis Complete</p>
                  <DemoBadge>Demo OCR</DemoBadge>
                </div>
                <div className="grid grid-cols-3 gap-2 text-center text-xs">
                  <Field label="Subject" value={ocr.subject} />
                  <Field label="Grade" value={ocr.grade} />
                  <Field label="Topic" value={ocr.topic} />
                </div>
                <div className="flex flex-col gap-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-muted-foreground">Extracted Text</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 gap-1.5 px-2 text-xs"
                      onClick={() => setEditing((v) => !v)}
                    >
                      <Pencil className="h-3.5 w-3.5" aria-hidden />
                      {editing ? 'Done' : 'Edit Extracted Text'}
                    </Button>
                  </div>
                  {editing ? (
                    <textarea
                      value={ocr.extractedText}
                      onChange={(e) => setOcrText(e.target.value)}
                      rows={3}
                      className="w-full rounded-xl border border-border bg-card p-3 text-base outline-none focus:ring-2 focus:ring-ring"
                      lang="hi"
                      aria-label="Editable extracted text"
                    />
                  ) : (
                    <p
                      className="rounded-xl border border-border bg-card p-3 font-display text-base"
                      lang="hi"
                    >
                      {ocr.extractedText}
                    </p>
                  )}
                </div>
              </div>
            ) : (
              <p className="text-center text-sm text-muted-foreground">
                Upload an image and run the analysis to see extracted lesson details here.
              </p>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-border bg-card p-2">
      <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="mt-0.5 text-sm font-bold">{value}</p>
    </div>
  )
}
