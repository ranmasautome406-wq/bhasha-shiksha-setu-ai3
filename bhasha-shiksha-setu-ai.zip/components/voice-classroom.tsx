'use client'

import { useRef, useState } from 'react'
import { Mic, Sparkles, Volume2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { SectionHeading, DemoBadge } from './section'
import { useStore } from './store'
import { TARGET_LANGUAGES } from '@/lib/demo-data'
import { speak, speechRecognitionSupported } from '@/lib/speech'
import { cn } from '@/lib/utils'

export function VoiceClassroom() {
  const { target, voiceResult, runVoice, toast } = useStore()
  const [listening, setListening] = useState(false)
  const [recognized, setRecognized] = useState<string | null>(null)
  const recRef = useRef<any>(null)

  const targetLabel = TARGET_LANGUAGES.find((l) => l.code === target)?.label ?? 'Santhali'

  async function finish(spoken?: string) {
    if (spoken) setRecognized(spoken)
    await runVoice()
    setListening(false)
  }

  function startListening() {
    if (!speechRecognitionSupported()) {
      toast('Live mic not supported here — showing demo sentence', 'info')
      setListening(true)
      setTimeout(() => finish('सब बच्चे अपनी किताब खोलिए।'), 1400)
      return
    }
    const SR: any =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
    const rec = new SR()
    rec.lang = 'hi-IN'
    rec.interimResults = false
    rec.maxAlternatives = 1
    rec.onresult = (e: any) => {
      const text = e.results?.[0]?.[0]?.transcript ?? 'सब बच्चे अपनी किताब खोलिए।'
      finish(text)
    }
    rec.onerror = () => {
      toast('Could not access microphone — showing demo sentence', 'error')
      finish('सब बच्चे अपनी किताब खोलिए।')
    }
    rec.onend = () => setListening(false)
    recRef.current = rec
    setRecognized(null)
    setListening(true)
    try {
      rec.start()
      toast('Listening… speak in Hindi', 'info')
    } catch {
      finish('सब बच्चे अपनी किताब खोलिए।')
    }
  }

  function tryDemo() {
    setRecognized(null)
    setListening(true)
    setTimeout(() => finish('सब बच्चे अपनी किताब खोलिए।'), 1400)
  }

  const spoken = recognized ?? voiceResult?.spoken

  return (
    <section id="voice" className="scroll-mt-20 py-16 sm:py-20">
      <div className="mx-auto max-w-4xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Voice Classroom"
          title="Speak Naturally. Teach Across Languages."
          subtitle="Speak a sentence in Hindi and hear it bridged into the mother tongue in real time."
        />

        <div className="mt-10 flex flex-col items-center gap-6 rounded-3xl border border-border bg-card p-8 shadow-sm">
          <button
            onClick={listening ? () => setListening(false) : startListening}
            aria-label={listening ? 'Stop listening' : 'Start speaking'}
            className={cn(
              'relative flex h-28 w-28 items-center justify-center rounded-full text-primary-foreground shadow-xl transition-transform hover:scale-105',
              listening ? 'bg-destructive pulse-ring' : 'bg-primary',
            )}
          >
            <Mic className="h-11 w-11" aria-hidden />
          </button>
          <p className="font-display text-lg font-bold">
            {listening ? 'Listening…' : 'Start Speaking'}
          </p>

          <div className="flex flex-wrap justify-center gap-3">
            <Button variant="outline" className="gap-2 border-primary/30" onClick={tryDemo}>
              <Sparkles className="h-4 w-4" aria-hidden />
              Try Demo Sentence
            </Button>
          </div>

          {spoken ? (
            <div className="grid w-full gap-4 sm:grid-cols-2">
              <div className="flex flex-col gap-2 rounded-2xl border border-border bg-secondary/40 p-4">
                <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Recognized Speech
                </span>
                <p className="font-display text-lg" lang="hi">
                  {spoken}
                </p>
              </div>
              <div className="flex flex-col gap-2 rounded-2xl border border-accent/40 bg-accent/5 p-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    Mother-Tongue Output · {targetLabel}
                  </span>
                  <DemoBadge>Demo</DemoBadge>
                </div>
                <p className="font-display text-lg text-pretty">
                  {voiceResult?.translated ?? 'Translating…'}
                </p>
                <Button
                  variant="ghost"
                  size="sm"
                  className="mt-1 w-fit gap-1.5 px-2 text-primary"
                  onClick={() => speak(voiceResult?.translated ?? '', 'hi-IN')}
                >
                  <Volume2 className="h-4 w-4" aria-hidden />
                  Play
                </Button>
              </div>
            </div>
          ) : null}

          {voiceResult ? (
            <div className="flex flex-wrap items-center justify-center gap-4 text-sm">
              <span className="rounded-full bg-secondary px-3 py-1.5 font-medium">
                Response Time: {voiceResult.responseTime.toFixed(1)} sec
              </span>
              <span className="flex items-center gap-2 rounded-full bg-accent/10 px-3 py-1.5 font-semibold text-accent-foreground">
                <span className="h-2 w-2 rounded-full bg-accent" />
                Prototype voice pipeline ready
              </span>
            </div>
          ) : null}
        </div>
      </div>
    </section>
  )
}
