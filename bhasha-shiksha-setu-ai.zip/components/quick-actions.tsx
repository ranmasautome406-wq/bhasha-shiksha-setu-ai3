'use client'

import { BookOpen, Camera, Globe, Mic } from 'lucide-react'
import { Button } from '@/components/ui/button'

function go(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
}

const CARDS = [
  {
    icon: Camera,
    title: 'AI Lesson Scanner',
    desc: 'Upload a textbook photo and convert it into a digital lesson.',
    cta: 'Scan Now',
    id: 'scanner',
  },
  {
    icon: Globe,
    title: 'Language Bridge',
    desc: "Translate educational content into the learner's mother tongue.",
    cta: 'Translate',
    id: 'language-bridge',
  },
  {
    icon: Mic,
    title: 'Voice Classroom',
    desc: 'Speak naturally and assist multilingual classroom communication.',
    cta: 'Start Speaking',
    id: 'voice',
  },
  {
    icon: BookOpen,
    title: 'Worksheet Builder',
    desc: 'Create bilingual learning activities instantly.',
    cta: 'Create Worksheet',
    id: 'worksheets',
  },
]

export function QuickActions() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {CARDS.map((c) => {
          const Icon = c.icon
          return (
            <div
              key={c.title}
              className="group flex flex-col gap-4 rounded-2xl border border-border bg-card p-5 shadow-sm transition-all hover:-translate-y-1 hover:border-primary/30 hover:shadow-lg"
            >
              <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                <Icon className="h-6 w-6" aria-hidden />
              </span>
              <div className="flex flex-col gap-1">
                <h3 className="font-display text-lg font-bold">{c.title}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{c.desc}</p>
              </div>
              <Button
                variant="ghost"
                className="mt-auto justify-start px-0 text-primary hover:bg-transparent hover:text-primary/80"
                onClick={() => go(c.id)}
              >
                {c.cta} →
              </Button>
            </div>
          )
        })}
      </div>
    </section>
  )
}
