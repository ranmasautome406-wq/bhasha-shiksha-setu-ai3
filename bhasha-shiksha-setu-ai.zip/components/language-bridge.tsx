'use client'

import { useState } from 'react'
import { ArrowLeftRight, Copy, Pencil, Star, Volume2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { SectionHeading, DemoBadge } from './section'
import { useStore } from './store'
import { TARGET_LANGUAGES, type LanguageCode } from '@/lib/demo-data'
import { speak } from '@/lib/speech'

export function LanguageBridge() {
  const { ocr, target, setTarget, translation, runTranslate, toast, saveLesson } = useStore()
  const [source, setSource] = useState('गिनती कीजिए और सही संख्या लिखिए।')
  const [busy, setBusy] = useState(false)
  const [editing, setEditing] = useState(false)

  const activeSource = ocr?.extractedText ?? source
  const targetLabel = TARGET_LANGUAGES.find((l) => l.code === target)?.label ?? 'Santhali'

  async function translate() {
    setBusy(true)
    await runTranslate(activeSource)
    setBusy(false)
    toast(`Translated to ${targetLabel}`, 'success')
  }

  return (
    <section id="language-bridge" className="scroll-mt-20 py-16 sm:py-20">
      <div className="mx-auto max-w-5xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Language Bridge"
          title="Translate into the Mother Tongue"
          subtitle="Convert Hindi educational content into the learner's familiar language."
        />

        <div className="mt-10 grid items-stretch gap-4 lg:grid-cols-[1fr_auto_1fr]">
          {/* Source */}
          <div className="flex flex-col gap-3 rounded-2xl border border-border bg-card p-5">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-muted-foreground">Source · Hindi</span>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 gap-1.5 px-2 text-xs"
                onClick={() => setEditing((v) => !v)}
                disabled={!!ocr}
              >
                <Pencil className="h-3.5 w-3.5" aria-hidden />
                {editing ? 'Done' : 'Edit'}
              </Button>
            </div>
            {editing && !ocr ? (
              <textarea
                value={source}
                onChange={(e) => setSource(e.target.value)}
                rows={4}
                lang="hi"
                aria-label="Source text"
                className="w-full rounded-xl border border-border bg-secondary/40 p-3 font-display text-lg outline-none focus:ring-2 focus:ring-ring"
              />
            ) : (
              <p className="min-h-24 rounded-xl bg-secondary/40 p-3 font-display text-lg" lang="hi">
                {activeSource}
              </p>
            )}
            {ocr ? (
              <p className="text-xs text-muted-foreground">Using text extracted by the scanner.</p>
            ) : null}
          </div>

          {/* Swap */}
          <div className="flex items-center justify-center">
            <button
              onClick={() => toast('Reverse translation is a demo preview', 'info')}
              aria-label="Swap languages"
              className="flex h-11 w-11 items-center justify-center rounded-full border border-border bg-card text-primary shadow-sm transition-transform hover:rotate-180 hover:border-primary/40"
            >
              <ArrowLeftRight className="h-5 w-5" aria-hidden />
            </button>
          </div>

          {/* Target */}
          <div className="flex flex-col gap-3 rounded-2xl border border-primary/30 bg-primary/5 p-5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-sm font-semibold text-muted-foreground">Target</span>
              <select
                value={target}
                onChange={(e) => setTarget(e.target.value as LanguageCode)}
                aria-label="Target language"
                className="rounded-lg border border-border bg-card px-3 py-1.5 text-sm font-semibold outline-none focus:ring-2 focus:ring-ring"
              >
                {TARGET_LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code}>
                    {l.label}
                  </option>
                ))}
              </select>
            </div>
            <div className="min-h-24 rounded-xl bg-card p-3">
              {translation ? (
                <p className="font-display text-lg text-pretty">{translation}</p>
              ) : (
                <p className="text-sm text-muted-foreground">Translated result appears here.</p>
              )}
            </div>
            {translation ? <DemoBadge>Demo Translation</DemoBadge> : null}
          </div>
        </div>

        <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
          <Button className="gap-2 px-6" onClick={translate} disabled={busy}>
            {busy ? 'Translating…' : 'Translate'}
          </Button>
          <Button
            variant="outline"
            className="gap-2"
            disabled={!translation}
            onClick={() => {
              const ok = speak(translation ?? '', target === 'english' ? 'en-US' : 'hi-IN')
              toast(ok ? 'Playing audio' : 'Speech not supported on this device', ok ? 'info' : 'error')
            }}
          >
            <Volume2 className="h-4 w-4" aria-hidden />
            Listen
          </Button>
          <Button
            variant="outline"
            className="gap-2"
            disabled={!translation}
            onClick={() => {
              navigator.clipboard?.writeText(translation ?? '')
              toast('Copied to clipboard', 'success')
            }}
          >
            <Copy className="h-4 w-4" aria-hidden />
            Copy
          </Button>
          <Button
            variant="outline"
            className="gap-2"
            disabled={!translation}
            onClick={() =>
              saveLesson({ topic: ocr?.topic ?? 'Numbers', language: targetLabel, translated: translation ?? '' })
            }
          >
            <Star className="h-4 w-4" aria-hidden />
            Save Lesson
          </Button>
        </div>

        <p className="mt-4 text-center text-xs text-muted-foreground">
          Demo translations are illustrative only and are not certified linguistic output.
        </p>
      </div>
    </section>
  )
}
