import { Languages } from 'lucide-react'

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-foreground py-10 text-background">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-4 px-4 text-center sm:px-6">
        <div className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Languages className="h-4 w-4" aria-hidden />
          </span>
          <span className="font-display text-lg font-bold">Bhasha Setu</span>
        </div>
        <p className="max-w-md text-sm text-background/70 text-balance">
          Bridging language and learning for every child, in every classroom — online or off.
        </p>
        <p className="text-xs text-background/50">
          Prototype for Smart India Hackathon · Smart Education. Demo data shown for illustration.
        </p>
      </div>
    </footer>
  )
}
