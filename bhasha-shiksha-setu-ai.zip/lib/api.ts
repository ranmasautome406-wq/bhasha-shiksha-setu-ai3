/**
 * Central API configuration for Bhasha Shiksha Setu AI.
 *
 * All AI calls go through this layer. Each function first tries to hit the
 * backend route. If the backend is unavailable (or returns an error), it falls
 * back to a local demo/mock response so the prototype always works offline.
 *
 * SECURITY: No API keys are ever placed in this file or anywhere in the
 * frontend. Real model credentials must live only in server-side route
 * handlers / environment variables.
 */

import {
  buildWorksheet,
  DEMO_FLASHCARDS,
  DEMO_OCR,
  DEMO_SIMPLIFIED,
  DEMO_TRANSLATIONS,
  DEMO_VOICE,
  tutorReply,
  type LanguageCode,
} from './demo-data'

export const API_CONFIG = {
  baseUrl: '/api',
  endpoints: {
    analyzeImage: '/analyze-image',
    translate: '/translate',
    explain: '/explain',
    voiceTranslate: '/voice-translate',
    generateWorksheet: '/generate-worksheet',
    generateFlashcards: '/generate-flashcards',
    chat: '/chat',
  },
  // Flip to true when a real backend is wired up.
  useLiveBackend: false,
}

async function callBackend<T>(endpoint: string, body: unknown, fallback: () => T): Promise<T> {
  if (!API_CONFIG.useLiveBackend) return fallback()
  try {
    const res = await fetch(`${API_CONFIG.baseUrl}${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })
    if (!res.ok) throw new Error(`Backend error ${res.status}`)
    return (await res.json()) as T
  } catch (err) {
    console.log('[v0] Backend unavailable, using demo response:', (err as Error).message)
    return fallback()
  }
}

const wait = (ms: number) => new Promise((r) => setTimeout(r, ms))

export async function analyzeImage(_meta: { name: string; size: number }) {
  await wait(300)
  return callBackend(API_CONFIG.endpoints.analyzeImage, _meta, () => ({ ...DEMO_OCR }))
}

export async function translate(text: string, target: LanguageCode) {
  await wait(200)
  return callBackend(API_CONFIG.endpoints.translate, { text, target }, () => ({
    original: text,
    translated: DEMO_TRANSLATIONS[target],
    isDemo: true,
  }))
}

export async function explain(grade: 1 | 2 | 3) {
  await wait(200)
  return callBackend(API_CONFIG.endpoints.explain, { grade }, () => ({
    grade,
    text: DEMO_SIMPLIFIED[grade],
  }))
}

export async function voiceTranslate(target: LanguageCode) {
  await wait(200)
  return callBackend(API_CONFIG.endpoints.voiceTranslate, { target }, () => ({
    spoken: DEMO_VOICE.spoken,
    translated: DEMO_VOICE.translated[target],
    responseTime: 1.8,
  }))
}

export async function generateWorksheet(opts: {
  count: number
  target: LanguageCode
  types: string[]
}) {
  await wait(300)
  return callBackend(API_CONFIG.endpoints.generateWorksheet, opts, () => ({
    questions: buildWorksheet(opts.count, opts.target).filter(
      (q) => opts.types.length === 0 || opts.types.includes(q.type),
    ),
  }))
}

export async function generateFlashcards(target: LanguageCode) {
  await wait(300)
  return callBackend(API_CONFIG.endpoints.generateFlashcards, { target }, () => ({
    cards: DEMO_FLASHCARDS.map((c) => ({
      emoji: c.emoji,
      hindi: c.hindi,
      target: c.translations[target],
      pronunciation: c.pronunciation,
    })),
  }))
}

export async function chat(message: string) {
  await wait(400)
  return callBackend(API_CONFIG.endpoints.chat, { message }, () => ({
    reply: tutorReply(message),
  }))
}
