/**
 * Central demo/mock dataset for Bhasha Shiksha Setu AI.
 *
 * IMPORTANT: These are illustrative demo strings for a hackathon prototype.
 * They are NOT certified linguistic translations. In production these would be
 * produced by real OCR / NMT / TTS models served from the backend.
 */

export type LanguageCode = 'ho' | 'mundari' | 'santhali' | 'english'

export const TARGET_LANGUAGES: { code: LanguageCode; label: string; native: string }[] = [
  { code: 'ho', label: 'Ho', native: 'ho' },
  { code: 'mundari', label: 'Mundari', native: 'ᱢᱩᱸᱰᱟᱨᱤ' },
  { code: 'santhali', label: 'Santhali', native: 'ᱥᱟᱱᱛᱟᱲᱤ' },
  { code: 'english', label: 'English', native: 'English' },
]

/** Mock OCR output returned by the "scan" pipeline. */
export const DEMO_OCR = {
  subject: 'Mathematics',
  grade: 'Class 1',
  topic: 'Numbers',
  extractedText: 'गिनती कीजिए और सही संख्या लिखिए।',
}

/** Demo translations keyed by target language. */
export const DEMO_TRANSLATIONS: Record<LanguageCode, string> = {
  ho: 'Lekha em pe aben sahi ronor ol pe. (Count and write the correct number.)',
  mundari: 'Lekha em pe ar sahi giti ol pe. (Count and write the correct number.)',
  santhali: 'ᱞᱮᱠᱷᱟ ᱮᱢ ᱯᱮ ᱟᱨ ᱥᱟᱦᱤ ᱜᱤᱛᱤ ᱚᱞ ᱯᱮ। (Count and write the correct number.)',
  english: 'Count the objects and write the correct number.',
}

/** Grade-level simplifications of a longer lesson. */
export const DEMO_ORIGINAL_LESSON =
  'संख्याएँ वस्तुओं की गणना करने में हमारी सहायता करती हैं। जब हम किसी समूह में वस्तुओं को गिनते हैं, तो हम प्रत्येक वस्तु के लिए एक संख्या का उपयोग करते हैं और अंतिम संख्या हमें कुल बताती है।'

export const DEMO_SIMPLIFIED: Record<1 | 2 | 3, string> = {
  1: 'Let us count! Point at each thing and say one number. 1 apple, 2 apples, 3 apples. The last number tells how many there are.',
  2: 'Numbers help us count things. When we count a group, we say one number for each object — 1, 2, 3, 4, 5. The last number we say is the total.',
  3: 'Numbers let us measure "how many". Counting means matching one number to each object in a group in order. The final number reached is the total count of the group.',
}

/** Voice classroom demo sentences. */
export const DEMO_VOICE = {
  spoken: 'सब बच्चे अपनी किताब खोलिए।',
  translated: {
    ho: 'Sanam hon-ko apa-apa puthi kate pe.',
    mundari: 'Sanam hon-ko apa-apa puthi nijar pe.',
    santhali: 'ᱥᱟᱱᱟᱢ ᱜᱤᱫᱽᱨᱟᱹ ᱟᱯᱟᱠ ᱯᱩᱛᱷᱤ ᱡᱷᱤᱡ ᱢᱮ।',
    english: 'All children, please open your books.',
  } as Record<LanguageCode, string>,
}

/** Flashcard vocabulary. */
export const DEMO_FLASHCARDS: {
  emoji: string
  hindi: string
  translations: Record<LanguageCode, string>
  pronunciation: string
}[] = [
  {
    emoji: '🍎',
    hindi: 'सेब',
    translations: { ho: 'Sada jo', mundari: 'Sada', santhali: 'ᱥᱟᱫᱟ', english: 'Apple' },
    pronunciation: 'sa-da',
  },
  {
    emoji: '🐘',
    hindi: 'हाथी',
    translations: { ho: 'Hati', mundari: 'Hati', santhali: 'ᱦᱟᱛᱤ', english: 'Elephant' },
    pronunciation: 'haa-thee',
  },
  {
    emoji: '🌳',
    hindi: 'पेड़',
    translations: { ho: 'Daru', mundari: 'Daru', santhali: 'ᱫᱟᱨᱩ', english: 'Tree' },
    pronunciation: 'da-ru',
  },
  {
    emoji: '☀️',
    hindi: 'सूरज',
    translations: { ho: 'Singi', mundari: 'Singi', santhali: 'ᱥᱤᱸᱜᱤ', english: 'Sun' },
    pronunciation: 'sin-gi',
  },
  {
    emoji: '🔢',
    hindi: 'संख्या',
    translations: { ho: 'Lekha', mundari: 'Lekha', santhali: 'ᱞᱮᱠᱷᱟ', english: 'Numbers' },
    pronunciation: 'le-kha',
  },
  {
    emoji: '💧',
    hindi: 'पानी',
    translations: { ho: 'Da', mundari: 'Da', santhali: 'ᱫᱟᱜ', english: 'Water' },
    pronunciation: 'da',
  },
]

/** Worksheet question bank by type. */
export function buildWorksheet(count: number, target: LanguageCode) {
  const t = (en: string) => DEMO_TRANSLATIONS[target] // simplistic demo mapping
  const bank = [
    {
      type: 'MCQ',
      hindi: '2 + 3 = ?',
      target: target === 'english' ? '2 + 3 = ?' : 'Lekha: 2 + 3 = ?',
      options: ['4', '5', '6', '7'],
      answer: '5',
    },
    {
      type: 'Fill in the blanks',
      hindi: '1, 2, ___, 4, 5',
      target: target === 'english' ? 'Fill: 1, 2, ___, 4, 5' : 'Purun: 1, 2, ___, 4, 5',
      options: [],
      answer: '3',
    },
    {
      type: 'MCQ',
      hindi: 'सबसे बड़ी संख्या कौन सी है?',
      target: target === 'english' ? 'Which is the largest number?' : 'Marang lekha okoy?',
      options: ['3', '8', '5', '2'],
      answer: '8',
    },
    {
      type: 'Match the following',
      hindi: 'चित्र को संख्या से मिलाइए',
      target: target === 'english' ? 'Match the picture to the number' : 'Chitra ar lekha jorao pe',
      options: ['🍎🍎 → 2', '🌳🌳🌳 → 3', '☀️ → 1'],
      answer: 'Match each group to its count',
    },
    {
      type: 'Short answer',
      hindi: 'तीन वस्तुओं के नाम लिखिए।',
      target: target === 'english' ? 'Write the names of three objects.' : 'Pe jinis ni nutum ol pe.',
      options: [],
      answer: 'Any three objects',
    },
    {
      type: 'MCQ',
      hindi: '5 - 2 = ?',
      target: target === 'english' ? '5 - 2 = ?' : 'Lekha: 5 - 2 = ?',
      options: ['1', '2', '3', '4'],
      answer: '3',
    },
    {
      type: 'Fill in the blanks',
      hindi: 'गिनती: 6, 7, ___, 9, 10',
      target: target === 'english' ? 'Count: 6, 7, ___, 9, 10' : 'Lekha: 6, 7, ___, 9, 10',
      options: [],
      answer: '8',
    },
  ]
  const out = []
  for (let i = 0; i < count; i++) out.push({ ...bank[i % bank.length], id: i + 1 })
  return out
}

/** Simple rule-based AI tutor for the demo. */
export function tutorReply(question: string): string {
  const q = question.toLowerCase()
  const add = q.match(/(\d+)\s*[+]\s*(\d+)/)
  if (add) {
    const a = Number(add[1])
    const b = Number(add[2])
    const seq = Array.from({ length: a + b }, (_, i) => i + 1).join(', ')
    return `${a} + ${b} = ${a + b}. Let's count together: ${seq}. Great job!`
  }
  const sub = q.match(/(\d+)\s*[-]\s*(\d+)/)
  if (sub) {
    const a = Number(sub[1])
    const b = Number(sub[2])
    return `${a} - ${b} = ${a - b}. Start at ${a} and count back ${b} steps.`
  }
  if (q.includes('example')) {
    return 'Here is an example: If you have 2 apples and get 3 more, you now have 5 apples. 2 + 3 = 5.'
  }
  if (q.includes('ask me') || q.includes('question')) {
    return 'Sure! Here is a question for you: How many is 4 + 1? Take your time and count on your fingers.'
  }
  if (q.includes('explain') || q.includes('lesson')) {
    return "Today's lesson is about counting numbers. We look at a group of objects and say one number for each object. The last number is the total!"
  }
  if (q.includes('homework')) {
    return 'I can help with your homework. Tell me the question, for example "3 + 2" or "count to 5", and we will solve it together.'
  }
  return "That's a good question! In this demo I can help you count, add and subtract small numbers. Try asking me something like '2 + 3'."
}

export const DASHBOARD_ACTIVITY = [
  { topic: 'Numbers', language: 'Santhali', type: 'Translation', status: 'Completed' },
  { topic: 'Animals', language: 'Ho', type: 'Worksheet', status: 'Completed' },
  { topic: 'Alphabet', language: 'Mundari', type: 'Flashcards', status: 'Completed' },
]
